public class FourCirclesTest {
    public static void main(String[] args) {
        System.out.println("If the JavaFX window opens with 4 styled circles, the test passes.");
    }
}
